"""TAO Publisher top-level exec environment."""

from ._cli import main  # pragma: no cover

if __name__ == "__main__":
    main()
